#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>